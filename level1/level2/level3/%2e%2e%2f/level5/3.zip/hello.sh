#!/bin/bash
# Hello World in Bash
echo "Hello, World!"
echo "Today is $(date +'%B %d, %Y')"
echo "Welcome to CrowdStrike scripting examples"
